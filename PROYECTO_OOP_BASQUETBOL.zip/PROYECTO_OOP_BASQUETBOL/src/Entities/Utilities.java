
package Entities;

/**
 *
 * @author IceCreamSandwich
 */
public interface Utilities {
    
}
