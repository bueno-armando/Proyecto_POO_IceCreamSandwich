/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

import javax.swing.JOptionPane;
import modelo.dao.DaoNewGame;

/**
 *
 * @author cesar
 */
public class LogicaNewGame {
    DaoNewGame daoNG = new DaoNewGame();
    
    public boolean logicaNewGameFoul()
    {
        JOptionPane.showMessageDialog(null,"si esta funcionando la comunicacion del  controlador a la logica del btn_foul");
        daoNG.daoNewGameFoul();
        return true;
    }
    
    public boolean logicaNewGamePoint()
    {
        JOptionPane.showMessageDialog(null,"si esta funcionando la comunicacion del  controlador a la logica del btn_point");
        daoNG.daoNewGamePoint();
        return true;
    }
    public boolean logicaNewGameAssit()
    {
        JOptionPane.showMessageDialog(null,"si esta funcionando la comunicacion del  controlador a la logica del btn_Assit");
        daoNG.daoNewGameAssit();
        return true;
    }
    public boolean logicaNewGameBlocks()
    {
        JOptionPane.showMessageDialog(null,"si esta funcionando la comunicacion del  controlador a la logica del btn_Blocks");
        daoNG.daoNewGameBlocks();
        return true;
    }
    public boolean logicaNewGameQTR()
    {
        JOptionPane.showMessageDialog(null,"si esta funcionando la comunicacion del  controlador a la logica del btn_QTR");
        daoNG.daoNewGameQTR();
        return true;
    }
}
