
package controlador;

/**
 *
 * @author cesar
 */
public class App {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ControladorVistaVentanaPrincipal.mostrarVentanaPrincipal();
    }
    
}
