/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import Logica.LogicaNewGame;
import javax.swing.JDialog;
import javax.swing.JOptionPane;


/**
 *
 * @author cesar
 */
public class ControladorVistaVentanaNewGame {
    private LogicaNewGame logicaNG = new LogicaNewGame();
    private JDialog  VentanaNewGame = null;
    
    public ControladorVistaVentanaNewGame(JDialog ventana)
    {
        VentanaNewGame = ventana;
    }
    
    public void btn_ExitVentanaNewGame()
    {
        VentanaNewGame.dispose();
    }
    
    public void btn_FoulVentanaNewGame()
    {
        JOptionPane.showMessageDialog(VentanaNewGame,"si esta funcionando la comunicacion del  controlador a la logica del btn_foul");
        logicaNG.logicaNewGameFoul();
    }
    public void btn_PointVentanaNewGame()
    {
        JOptionPane.showMessageDialog(VentanaNewGame,"si esta funcionando la comunicacion del  controlador a la logica del btn_Point");
        logicaNG.logicaNewGamePoint();
    }
    public void btn_AssitVentanaNewGame()
    {
        JOptionPane.showMessageDialog(VentanaNewGame,"si esta funcionando la comunicacion del  controlador a la logica del btn_Assit");
        logicaNG.logicaNewGameAssit();
    }
    public void btn_BlocksVentanaNewGame()
    {
        JOptionPane.showMessageDialog(VentanaNewGame,"si esta funcionando la comunicacion del  controlador a la logica del btn_Blocks");
        logicaNG.logicaNewGameBlocks();
    }
    public void btn_QRT_VentanaNewGame()
    {
        JOptionPane.showMessageDialog(VentanaNewGame,"si esta funcionando la comunicacion del  controlador a la logica del QTR");
        logicaNG.logicaNewGameQTR();
    }
    
}
