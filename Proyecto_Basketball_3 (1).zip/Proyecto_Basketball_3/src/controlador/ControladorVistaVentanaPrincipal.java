/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;
import vista.VentanaPrincipal;
import vista.VentanaNewGame;
/**
 *
 * @author cesar
 */
public class ControladorVistaVentanaPrincipal {
    public static VentanaPrincipal vPrincipal = new VentanaPrincipal();
    public static VentanaNewGame vNewGame = new VentanaNewGame();
    
    //Mostrar ventana principal
    public static void mostrarVentanaPrincipal()
    {
        vPrincipal.setVisible(true);
    }
    //Mostrar ventana New Game
    public static void mostrarVentanaNewGame()
    {
        vNewGame.setVisible(true);
    }
    //Mostrar ventana Stats
    
    //Mostrar ventana LoadTeams
    
    //Mostrar ventana Leaderboard
    
    //Enventos VentanaPrincipal
    public static void btn_Salir(){
        System.exit(0);
    }
}
